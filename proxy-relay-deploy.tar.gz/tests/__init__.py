"""
Test suite for Proxy Relay System.
"""
